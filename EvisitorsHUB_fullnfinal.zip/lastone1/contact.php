<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="Website by Suhani" name="description">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Title -->
    <title>E-VISITOR HUB -Explore Rewa City With Us</title>
    <!-- Favicon -->
    <link rel="icon" href="pic/favicon.jpeg">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <!-- Header Area Start -->
    <header class="header-area">
        <!-- Search Form -->
        <div class="search-form d-flex align-items-center">
            <div class="container">
                <form action="contact.php" method="get">
                    <input type="search" name="id" id="searchFormInput"
                        placeholder="Type your keyword ...">
                    <button type="submit"><i class="icon_search"></i></button>
                </form>
            </div>
        </div>
        <!-- Top Header Area Start -->
        <div class="top-header-area">
            <div class="container">
                <div class="row">

                    <div class="col-6">
                        <div class="top-header-content">
                            <a href="tel:8839072140" style="font-family: exotc350_dmbd_btdemi-bold;font-size:20px;"><i
                                    class="icon_phone"></i> <span>8839072140</span></a>
                            <a href="mailto:evisitorshub@gmail.com"
                                style="font-family: exotc350_dmbd_btdemi-bold;font-size:20px;"><i class="icon_mail"></i>
                                <span>evisitorshub@gmail.com</span></a>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="top-header-content">
                            <!-- Top Social Area -->
                            <div class="top-social-area ml-auto">
                                <a href="https://www.facebook.com/profile.php?id=100077733467135"><i
                                        class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href=" https://twitter.com/EVisitorshub?t=wIj5AuKJA60SIuJTtv28VQ&s=08"><i
                                        class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="https://www.instagram.com/invites/contact/?i=d49e1k1e6dx8&utm_content=ntsv8ay"><i
                                        class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Top Header Area End -->

        <!-- Main Header Start -->
        <div class="main-header-area">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Classy Menu -->
                    <nav class="classy-navbar justify-content-between" id="robertoNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.html">
                            <img src="pic/logo.jpeg" alt="" style="height: 70px;">
                        </a>
                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Menu Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>
                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul id="nav">
                                <li class="active"><a href="./index.php"
                                            style="font-size: 18px;font-family: 'classyfonts';font-weight:bolder;">Home</a>
                                    </li>
                                    <li><a href="./about.php"
                                            style="font-size: 18px;font-family: 'classyfonts';font-weight:bolder;">About</a>
                                    </li>

                                    <li><a href="#"
                                            style="font-size: 18px;font-family: 'classyfonts';font-weight:bolder;">Educations</a>
                                        <ul class="dropdown">
                                            <li><a href="./school.php" style="font-size: 18px;font-family: 'classyfonts';
                                            font-weight:bolder;font-size: 18px;">- Schools</a></li>
                                            <li><a href="./college.php" style="font-family: 'classyfonts';
                                            font-weight:bolder;font-size: 18px;">- Colleges</a></li>
                                            <li><a href="./library.php" style="font-family: 'classyfonts';
                                                font-weight:bolder;font-size: 18px;">- Libraries</a></li>
                                        </ul>
                                    <li><a href="./tourist.php" style="font-size: 18px;
                                           font-family: 'classyfonts';font-weight:bolder;">Tourist Places</a></li>
                                    <li><a href="./hospital.php" style="font-size: 18px;
                                           font-family: 'classyfonts';font-weight:bolder;">Hospitals</a></li>
                                    <li><a href="#" style="font-size: 18px;
                                           font-family: 'classyfonts';font-weight:bolder;">Food Gallery</a>
                                        <ul class="dropdown">
                                            <li><a href="hotel.php" style="font-size: 18px;
                                                font-family: 'classyfonts';
                                                font-weight:bolder;">- Hotels Inn</a></li>
                                            <li><a href="./restaurant.php" style="font-size: 18px;
                                                font-family: 'classyfonts';font-weight:bolder;">
                                                    - Restaurants</a></li>

                                    </li>
                            </ul>
                            </li>

                            <li><a href="./contact.php"
                                    style="font-size: 18px;font-family: 'classyfonts';font-weight:bolder;">Contact</a>
                            </li>
                                </ul>

                                <!-- Search -->
                                <div class="search-btn ml-4">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                </div>
                                <!-- Nav End -->
                            </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->

    <!-- Breadcrumb Area Start -->
    <div class="breadcrumb-area contact-breadcrumb bg-img bg-overlay jarallax" 
    style="background-image: url(img/contactus\ \(1\).jpg);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-content text-center mt-100">
                        <h2 class="page-title">Contact Us</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End -->

    <!-- Google Maps & Contact Info Area Start -->
 <?php
include('config.php');
if(isset($_GET['id']))
{
    $id=mysqli_real_escape_string($conn,$_GET['id']);

        $table="search_content";
        $sql="SELECT * FROM `search_content` WHERE CONCAT(`ID`,`Title`,`Hotel_Name`,`Contact_No`,`Address`)LIKE '%$id%'";
        $res=mysqli_query($conn,$sql);
		   $row=mysqli_fetch_array($res);	
?>   
                            <!-- For Search-->
    <section class="google-maps-contact-info">
        <div class="container-fluid">
            <div class="google-maps-contact-content">
                <div class="row">
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <h4>Phone</h4>
                            <p><?php echo $row['Contact_No'];?></p>
                        </div>
                    </div>
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <h4>Address</h4>
                            <p><?php echo $row['Address'];?></p>
                        </div>
                    </div>
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <h4>Services</h4>
                            <p><?php echo $row['Services'];?></p>
                        </div>
                    </div>
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                            <h4>Email</h4>
                            <p><?php echo $row['Email'];?></p>
                        </div>
                    </div>
                </div>

                <!-- Google Maps -->
                <div id="map"class="img-responsive" style=" height: 450px;"></div>
				<script src="https://maps.googleapis.com/maps/api/js?key=CBk2kP31XJj7vn8j8"></script>
				<script>
					var map_parameters = { center: {lat:24.515780, lng:81.272120}, zoom: 8 };
					var map = new google.maps.Map(document.getElementById('map'), map_parameters);
				</script>
			  </div>

            </div>
        </div>
    </section>
<?php
}
	        /*For ByDefault*/
else{
?>
   <section class="google-maps-contact-info">
        <div class="container-fluid">
            <div class="google-maps-contact-content">
                <div class="row">
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <h4>Phone</h4>
                            <p>91+ 8016804120</p>
                        </div>
                    </div>
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <h4>Address</h4>
                            <p>Rewa Madhya Pradesh 486001</p>
                        </div>
                    </div>
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <h4>Services</h4>
                            <p>24X7</p>
                        </div>
                    </div>
                    <!-- Single Contact Info -->
                    <div class="col-6 col-lg-3">
                        <div class="single-contact-info">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                            <h4>Email</h4>
                            <p>evisitorshub@gmail.com</p>
                        </div>
                    </div>
                </div>

                <!-- Google Maps -->
                <div id="map"class="img-responsive" style=" height: 450px;"></div>
				<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAqnngTs492JPUC86nAKHRV8yFLFTk8xMo"></script>
				<script>
					var map_parameters = { center: {lat:24.515780, lng:81.272120}, zoom: 8 };
					var map = new google.maps.Map(document.getElementById('map'), map_parameters);
				</script>
			  </div>

            </div>
        </div>
    </section>
    <?php
}
?>
    <!-- Google Maps & Contact Info Area End -->

    <!-- Contact Form Area Start -->
    <div class="suhani-contact-form-area section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Section Heading -->
                    <div class="section-heading text-center wow fadeInUp" data-wow-delay="100ms">
                        <h6>Contact Us</h6>
                        <h2>Leave Message</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <!-- Form -->
                    <div class="suhani-contact-form">
                      
                       <form action="get_response.php" method="post">
                            <div class="row">
                                <div class="col-12 col-lg-6 wow fadeInUp" data-wow-delay="100ms">
                                    <input type="text" name="message_name" class="form-control mb-30"
                                     placeholder="Your Name" required>
                                </div>
                                <div class="col-12 col-lg-6 wow fadeInUp" data-wow-delay="100ms">
                                    <input type="email" name="message_email" class="form-control mb-30" 
                                    placeholder="Your Email" required>
                                </div>
                                <div class="col-12 wow fadeInUp" data-wow-delay="100ms">
                                    <textarea name="message" class="form-control mb-30"
                                     placeholder="Your Message" required></textarea>
                                </div>
                                <div class="col-12 text-center wow fadeInUp" data-wow-delay="100ms">
                                   <button type="submit" class="btn suhani-btn mt-15">

                                    Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact Form Area End -->

     <!-- Footer Area Start -->
     <footer class="footer-area section-padding-80-0">
        <!-- Main Footer Area -->
        <div class="main-footer-area" style="margin-top: -60px;">
            <div class="container">
                <div class="row align-items-baseline justify-content-between">
                    <!-- Single Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget mb-80">
                            <!-- Footer Logo -->
                            <a href="#" class="footer-logo">
                                <img src="pic/foot_logo.jpeg" alt="" style="height: 78px;
                                width: 191px;">   
                            </a>
                            <span style="text-align: justify;font-size:18px;">E-visitor Hub is something which points out the way and leads others on a trip or tour. Generally, this will work at a specific location, city or province. AND with this we are focusing in the REWA city.
                            </span>
                            
                        </div>
                    </div>
                    <!-- Single Footer Widget Area -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget mb-80">
                            <!-- Widget Title -->
                            <h5 class="widget-title">Our Info</h5>
                            <h4>8839072140</h4>
                            <span style="text-align: justify;font-size:18px;">suhanisrivastava664@gmail.com</span>
                            <span style="text-align: justify;font-size:18px;">Rewa Madhya Pradesh,486001</span>
                            <!-- Single Blog Area -->

                        </div>
                    </div>

                    <!-- Single Footer Widget Area -->
                    <div class="col-12 col-sm-4 col-lg-2">
                        <div class="single-footer-widget mb-80">
                            <!-- Widget Title -->
                            <h5 class="widget-title" style="font-size:18px;">Links</h5>

                            <!-- Footer Nav -->
                            <ul class="footer-nav">
                                <li><a href="about.html" style="font-size:18px;"><i class="fa fa-caret-right"
                                     aria-hidden="true"></i> About Us</a></li>
                                <li><a href="hospital.html" style="font-size:18px;"><i class="fa fa-caret-right"
                                     aria-hidden="true"></i>Hospitals </a></li>
                                <li><a href="college.html"style="font-size:18px;"><i class="fa fa-caret-right"
                                     aria-hidden="true"></i>Colleges </a></li>
                                <li><a href="contact.html"style="font-size:18px;"><i class="fa fa-caret-right"
                                     aria-hidden="true"></i> Contact Us</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- Single Footer Widget Area -->
                    <div class="col-12 col-sm-8 col-lg-4">
                        <div class="single-footer-widget mb-80">
                            <!-- Widget Title -->
                            <h5 class="widget-title" style="font-size:18px;" style="font-size:18px;">Subscribe Us</h5>
                            <span style="font-size:18px;">Subscribe or get notification about new updates.</span>

                            <!-- Newsletter Form -->
                            <form action="contact_mail.php" class="nl-form">
                                <input type="email" class="form-control" placeholder="Enter your email..."style="font-size:18px;">
                                <button type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Copywrite Area -->
        <div class="container">
            <div class="copywrite-content">
                <div class="row align-items-center">
                    <div class="col-12 col-md-8">
                        <!-- Copywrite Text -->
                        <div class="copywrite-text">
                            <p style="font-size:18px;">
                                Designed and Developed By Code Blaster Team
</p>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <!-- Social Info -->
                        <div class="social-info">
                            <a href="https://www.facebook.com/profile.php?id=100077733467135"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <a href=" https://twitter.com/EVisitorshub?t=wIj5AuKJA60SIuJTtv28VQ&s=08"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <a href="https://www.instagram.com/invites/contact/?i=d49e1k1e6dx8&utm_content=ntsv8ay"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- **** All JS Files ***** -->
    <!-- jQuery 2.2.4 -->
    <script src="js/jquery.min.js"></script>
    <!-- Popper -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All Plugins -->
    <script src="js/code.bundle.js"></script>
    <!-- Active -->
    <script src="js/default-assets/active.js"></script>

</body>

</html>