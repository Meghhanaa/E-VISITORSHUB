<?php
$con=mysqli_connect("localhost","root","Sakshi@26","search_engine");
?>
